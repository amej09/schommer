<?php
declare(strict_types=1);

namespace T3SBS\T3sbootstrap\Controller;

/*
 * This file is part of the TYPO3 extension t3sbootstrap.
 *
 * For the full copyright and license information, please read the
 * LICENSE file that was distributed with this source code.
 */
class ConfigController extends AbstractCompatibilityController
{

	public function initializeAction()
	{
		parent::initializeAction();
	}
}
