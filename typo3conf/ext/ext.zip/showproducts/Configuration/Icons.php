<?php

return [
    'showproducts-plugin-allproduct' => [
        'provider' => \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
        'source' => 'EXT:showproducts/Resources/Public/Icons/user_plugin_allproduct.svg'
    ],
];
