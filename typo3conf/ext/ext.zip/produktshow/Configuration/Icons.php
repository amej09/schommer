<?php

return [
    'produktshow-plugin-prs' => [
        'provider' => \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
        'source' => 'EXT:produktshow/Resources/Public/Icons/user_plugin_prs.svg'
    ],
];
